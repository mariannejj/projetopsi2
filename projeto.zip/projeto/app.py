from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response
from flask_login import LoginManager, login_required, login_user, logout_user, current_user, UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'guilherme'

# Configura banco SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///banco.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

login_manager = LoginManager(app)

# Modelos
class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False, unique=True)
    senha = db.Column(db.String(150), nullable=False)

class Produto(db.Model):
    __tablename__ = 'produtos'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    preco = db.Column(db.Float, nullable=False)
    descricao = db.Column(db.String(300))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Rotas
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        usuario = User.query.filter_by(nome=email).first()
        if usuario and check_password_hash(usuario.senha, senha):
            login_user(usuario)
            resp = make_response(redirect(url_for('dash')))
            resp.set_cookie('nome', usuario.nome)
            return resp
        flash('Erro: usuário ou senha inválidos')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        nome = request.form['email']
        senha = request.form['senha']
        if User.query.filter_by(nome=nome).first():
            flash('Erro: usuário já existe')
            return redirect(url_for('register'))
        senha_hash = generate_password_hash(senha)
        novo = User(nome=nome, senha=senha_hash)
        db.session.add(novo)
        db.session.commit()
        login_user(novo)
        resp = make_response(redirect(url_for('dash')))
        resp.set_cookie('nome', novo.nome)
        return resp
    return render_template('register.html')

@app.route('/dash')
@login_required
def dash():
    return render_template('dashboard.html')

# --- CRUD Produtos ---
@app.route('/produtos')
@login_required
def listar_produtos():
    produtos = Produto.query.all()
    return render_template('produtos.html', produtos=produtos)

@app.route('/produtos/novo', methods=['GET','POST'])
@login_required
def novo_produto():
    if request.method == 'POST':
        nome = request.form['nome']
        preco = request.form['preco']
        descricao = request.form['descricao']
        p = Produto(nome=nome, preco=preco, descricao=descricao)
        db.session.add(p)
        db.session.commit()
        flash('Produto cadastrado com sucesso')
        return redirect(url_for('listar_produtos'))
    return render_template('novo_produto.html')

@app.route('/produtos/editar/<int:id>', methods=['GET','POST'])
@login_required
def editar_produto(id):
    produto = Produto.query.get_or_404(id)
    if request.method == 'POST':
        produto.nome = request.form['nome']
        produto.preco = request.form['preco']
        produto.descricao = request.form['descricao']
        db.session.commit()
        flash('Produto atualizado com sucesso')
        return redirect(url_for('listar_produtos'))
    return render_template('editar_produto.html', produto=produto)

@app.route('/produtos/excluir/<int:id>')
@login_required
def excluir_produto(id):
    produto = Produto.query.get_or_404(id)
    db.session.delete(produto)
    db.session.commit()
    flash('Produto excluído com sucesso')
    return redirect(url_for('listar_produtos'))

@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
