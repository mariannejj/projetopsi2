from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_required, login_user, logout_user, current_user, UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.exc import OperationalError  
from sqlalchemy import inspect  

app = Flask(__name__)
app.secret_key = 'guilherme' 

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///banco.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = 'login'  

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), nullable=False, unique=True)
    senha = db.Column(db.String(150), nullable=False)

class Produto(db.Model):
    __tablename__ = 'produtos'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    preco = db.Column(db.Float, nullable=False)
    descricao = db.Column(db.String(300))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            email = request.form.get('email', '').strip()
            senha = request.form.get('senha', '').strip()
            
            inspector = inspect(db.engine)
            if not inspector.has_table('users'):
                flash('Erro interno: Banco de dados não inicializado. Reinicie o app.')
                return redirect(url_for('login'))
            
            usuario = User.query.filter_by(email=email).first()
            if usuario and check_password_hash(usuario.senha, senha):
                login_user(usuario)
                return redirect(url_for('dash'))
            flash('Erro: E-mail ou senha inválidos')
        except OperationalError as e:
            flash('Erro no login: Banco de dados indisponível.')
            print(f"Erro SQLAlchemy no login: {e}")
        except Exception as e:
            flash('Erro inesperado no login.')
            print(f"Erro geral no login: {e}")
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            nome = request.form.get('nome', '').strip()
            email = request.form.get('email', '').strip()
            senha = request.form.get('senha', '').strip()
            
            if not nome or not email or not senha:
                flash('Erro: Todos os campos são obrigatórios')
                return redirect(url_for('register'))
            if len(senha) < 3:
                flash('Erro: Senha deve ter pelo menos 3 caracteres')
                return redirect(url_for('register'))
            if '@' not in email:
                flash('Erro: E-mail inválido')
                return redirect(url_for('register'))
            
            inspector = inspect(db.engine)
            if not inspector.has_table('users'):
                flash('Erro interno: Banco de dados não inicializado. Reinicie o app.')
                return redirect(url_for('register'))
            
            usuario_existente = User.query.filter_by(email=email).first()
            if usuario_existente:
                flash('Erro: E-mail já cadastrado')
                return redirect(url_for('register'))
            
            senha_hash = generate_password_hash(senha)
            novo = User(nome=nome, email=email, senha=senha_hash)
            db.session.add(novo)
            db.session.commit()
            login_user(novo)
            flash('Cadastro realizado com sucesso! Bem-vindo, ' + nome)
            return redirect(url_for('dash'))
            
        except OperationalError as e:   
            if "no such table" in str(e):
                flash('Erro: Banco de dados não inicializado. Reinicie o app.')
            else:
                flash(f'Erro no cadastro: {str(e)}')
            db.session.rollback()
            print(f"Erro SQLAlchemy: {e}")
            return redirect(url_for('register'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erro inesperado no cadastro: {str(e)}')
            print(f"Erro geral: {e}")
            return redirect(url_for('register'))
    
    return render_template('register.html')

@app.route('/dash')
@login_required
def dash():
    return render_template('dashboard.html')

@app.route('/produtos')
@login_required
def listar_produtos():
    try:
        inspector = inspect(db.engine)
        if not inspector.has_table('produtos'):
            flash('Erro interno: Banco de dados não inicializado. Reinicie o app.')
            return redirect(url_for('dash'))
        
        produtos = Produto.query.all()
        return render_template('produtos.html', produtos=produtos)
    except OperationalError as e:
        flash('Erro ao carregar produtos: Banco indisponível.')
        print(f"Erro SQLAlchemy em listar_produtos: {e}")
        return redirect(url_for('dash'))
    except Exception as e:
        flash('Erro inesperado ao carregar produtos.')
        print(f"Erro geral em listar_produtos: {e}")
        return redirect(url_for('dash'))

@app.route('/produtos/novo', methods=['GET', 'POST'])
@login_required
def novo_produto():
    if request.method == 'POST':
        try:
            nome = request.form.get('nome', '').strip()
            preco_str = request.form.get('preco', '0').strip()
            descricao = request.form.get('descricao', '').strip()
            
            if not nome:
                flash('Erro: Nome obrigatório')
                return render_template('novo_produto.html')
            try:
                preco = float(preco_str)
                if preco <= 0:
                    flash('Erro: Preço deve ser positivo')
                    return render_template('novo_produto.html')
            except ValueError:
                flash('Erro: Preço deve ser um número válido')
                return render_template('novo_produto.html')
            
            inspector = inspect(db.engine)
            if not inspector.has_table('produtos'):
                flash('Erro interno: Banco de dados não inicializado.')
                return redirect(url_for('listar_produtos'))
            
            p = Produto(nome=nome, preco=preco, descricao=descricao)
            db.session.add(p)
            db.session.commit()
            flash('Produto cadastrado com sucesso')
            return redirect(url_for('listar_produtos'))
        except OperationalError as e:
            db.session.rollback()
            flash('Erro ao cadastrar produto: Banco indisponível.')
            print(f"Erro SQLAlchemy em novo_produto: {e}")
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao cadastrar produto: {str(e)}')
            print(f"Erro geral em novo_produto: {e}")
        return render_template('novo_produto.html')
    
    return render_template('novo_produto.html')

@app.route('/produtos/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_produto(id):
    try:
        produto = Produto.query.get_or_404(id)
    except OperationalError:
        flash('Erro: Banco indisponível.')
        return redirect(url_for('listar_produtos'))
    
    if request.method == 'POST':
        try:
            produto.nome = request.form.get('nome', '').strip()
            preco_str = request.form.get('preco', '0').strip()
            produto.descricao = request.form.get('descricao', '').strip()
            
            if not produto.nome:
                flash('Erro: Nome obrigatório')
                return render_template('editar_produto.html', produto=produto)
            try:
                preco = float(preco_str)
                if preco <= 0:
                    flash('Erro: Preço deve ser positivo')
                    return render_template('editar_produto.html', produto=produto)
                produto.preco = preco
            except ValueError:
                flash('Erro: Preço deve ser um número válido')
                return render_template('editar_produto.html', produto=produto)
            
            db.session.commit()
            flash('Produto atualizado com sucesso')
            return redirect(url_for('listar_produtos'))
        except OperationalError as e:
            db.session.rollback()
            flash('Erro ao atualizar produto: Banco indisponível.')
            print(f"Erro SQLAlchemy em editar_produto: {e}")
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao atualizar produto: {str(e)}')
            print(f"Erro geral em editar_produto: {e}")
        return render_template('editar_produto.html', produto=produto)
    
    return render_template('editar_produto.html', produto=produto)

@app.route('/produtos/excluir/<int:id>')
@login_required
def excluir_produto(id):
    try:
        produto = Produto.query.get_or_404(id)
        db.session.delete(produto)
        db.session.commit()
        flash('Produto excluído com sucesso')
    except OperationalError as e:
        db.session.rollback()
        flash('Erro ao excluir produto: Banco indisponível.')
        print(f"Erro SQLAlchemy em excluir_produto: {e}")
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao excluir produto: {str(e)}')
        print(f"Erro geral em excluir_produto: {e}")
    return redirect(url_for('listar_produtos'))

@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    try:
        with app.app_context():
            db.create_all()  
            print("✅ Banco de dados 'banco.db' criado/atualizado com sucesso!")
            print("   - Tabela 'users' criada (campos: id, nome, email, senha).")
            print("   - Tabela 'produtos' criada (campos: id, nome, preco, descricao).")
            
            inspector = inspect(db.engine)
            if inspector.has_table('users'):
                print("   Tabela 'users' confirmada no banco.")
            else:
                print("   Erro: Tabela 'users' não foi criada. Verifique o banco manualmente.")
                
            if inspector.has_table('produtos'):
                print("   Tabela 'produtos' confirmada no banco.")
            else:
                print("   Erro: Tabela 'produtos' não foi criada.")
                
    except Exception as e:
        print(f" Erro ao criar banco/tabelas: {e}")
        print("   - Certifique-se de que o diretório tem permissões de escrita.")
        print("   - Delete 'banco.db' se existir e tente novamente.")
    
    app.run(debug=True)